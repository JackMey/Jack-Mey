export type AlteryxConnection = {
  origin: { ToolID: string; Connection: string };
  destination: { ToolID: string; Connection: string };
}
