import { Tool } from './tool';

export interface UnknownTool extends Tool {
  Properties: string;
}
