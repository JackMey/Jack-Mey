export type AlteryxWorkflow = {
    id: string;
    name: string;
    timeAdded: string;
    content: Record<string, any>;
    xml: string;
};
